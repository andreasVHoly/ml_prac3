README for the third machine learning practical

VHLAND002 - Andreas von Holy

Files Submitted:
percepnetwork.h
percepnetwork.cpp
set.h
testset.h
testset.cpp
perceptron.h
perceptron.cpp
main.cpp
README.txt
makefile



Answers to Questions:

Q1:

It took 204 iteration to reach and error of 0 on the Ubuntu lab machines.
It took 207 iteration to reach and error of 0 on my Windows laptop.

Q2:

The alogirhtm took 6 iterations with a threshold function to reach and error of 0. 
It is achieved in less iterations as we come closer to the desired values faster as we automatically round values at each step to 1 or -1.


Output files:

The output files will be located in the same directory where the program is run. It creates an output file (threshold.txt or linear.txt) each time the algorithm is run with the results. Default ones have been provided which come where made from running the program.


Instructions:

1. In command window go to the directory with the files in.
2. Type 'make' to build the files.
3. Type 'make run' to run the program.
4. When prompted type either 'a' to use the activation function or 't' to use the threshold function.
5. Wait for the program to output and finish.
6. Type x to exit.
7. Type 'make clean' to clean compiled files.

