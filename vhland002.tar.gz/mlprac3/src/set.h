#ifndef SET_H
#define SET_H

namespace vhland002{
class Set
{
public:

    Set(float input1, float input2,float input3,float input4, float output):
        input1(input1), input2(input2), input3(input3), input4(input4), output(output){}


    float input1;
    float input2;
    float input3;
    float input4;
    float output;
};
}//vhland002
#endif // SET_H

