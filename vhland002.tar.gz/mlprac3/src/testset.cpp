#include "testset.h"
namespace vhland002{


void TestSet::addSet(Set set){
    sets.push_back(set);
}


}


